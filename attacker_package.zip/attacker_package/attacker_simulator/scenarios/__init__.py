"""Attack scenarios package."""
